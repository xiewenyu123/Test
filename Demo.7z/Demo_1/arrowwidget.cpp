﻿#include "arrowwidget.h"
#include "ui_arrowwidget.h"

#include <QHBoxLayout>
#include <QPainter>
#include <QGraphicsDropShadowEffect>

#include <QLabel>
#include <QDebug>

#define SHADOW_WIDTH 10                // 窗口阴影宽度;
#define TRIANGLE_WIDTH 15               // 小三角的宽度;
#define TRIANGLE_HEIGHT 10              // 小三角的高度;
#define BORDER_RADIUS 5                 // 窗口边角的弧度;

ArrowWidget::ArrowWidget(QWidget *parent)
    : QWidget(parent)
    , m_startX(0)
    , m_triangleWidth(TRIANGLE_WIDTH)
    , m_triangleHeight(TRIANGLE_HEIGHT)
{
    setWindowFlags(Qt::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);

    // 设置阴影边框;
    QGraphicsDropShadowEffect* shadowEffect = new QGraphicsDropShadowEffect(this);
    shadowEffect->setOffset(0, 0);
    shadowEffect->setColor(Qt::gray);
    shadowEffect->setBlurRadius(SHADOW_WIDTH);
    this->setGraphicsEffect(shadowEffect);


    setFixedSize(100,100);

//    m_startY = this->height() / 2;

}

void ArrowWidget::setCenterWidget(QWidget* widget)
{
    QHBoxLayout* hMainLayout = new QHBoxLayout(this);
    hMainLayout->addWidget(widget);
    hMainLayout->setSpacing(0);
    hMainLayout->setContentsMargins(SHADOW_WIDTH + TRIANGLE_WIDTH, SHADOW_WIDTH, SHADOW_WIDTH, SHADOW_WIDTH);
}

// 设置小三角显示的起始位置;
void ArrowWidget::setStartPos(int startY)
{
    m_startY = startY;
}

void ArrowWidget::setTriangleInfo(int width, int height)
{
    m_triangleWidth = width;
    m_triangleHeight = height;
}

void ArrowWidget::paintEvent(QPaintEvent *)
{

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setPen(Qt::NoPen);
    painter.setBrush(QColor(255, 255, 255));


    QPolygon trianglePolygon; //竖三角
    trianglePolygon << QPoint(m_startX,m_startY);
    trianglePolygon << QPoint(m_startX+SHADOW_WIDTH+m_triangleHeight,m_startY + m_triangleWidth / 2);
    trianglePolygon << QPoint(m_startX+SHADOW_WIDTH+m_triangleHeight,m_startY - m_triangleWidth/2);

    QPainterPath drawPath;   //画区域
    drawPath.addRoundedRect(QRect(m_startX + SHADOW_WIDTH + m_triangleHeight, SHADOW_WIDTH,\
                                  width() - SHADOW_WIDTH * 2 - m_triangleHeight, height() - SHADOW_WIDTH *2),BORDER_RADIUS, BORDER_RADIUS);
//    qDebug() << width();
    // Rect + Triangle;
    drawPath.addPolygon(trianglePolygon);
    painter.drawPath(drawPath);
}
