﻿#include "test.h"
#include "ui_test.h"
#include <QToolTip>
#include <QDebug>

Test::Test(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Test)
{
    demo1 = new Demo_1(this);
    //    demo1->setWindowFlags(Qt::WindowStaysOnTopHint);
    demo1->setWindowFlags(Qt::WindowStaysOnTopHint);
    demo1->show();
    demo1->hide();


    ui->setupUi(this);


    ui->pushButton->installEventFilter(this);
}

Test::~Test()
{
    delete ui;
}


bool Test::eventFilter(QObject *obj, QEvent *event)
{

    if(obj == ui->pushButton)
    {
        if(event->type() == QEvent::ToolTip)
        {
            this->Jposition();
        }
        else if(event->type() == QEvent::Leave)
        {
            demo1->close();
        }
    }
    return QObject::eventFilter(obj, event);

}


void Test::Jposition()
{
    int x=this->mapFromGlobal(QCursor().pos()).x();   //获取鼠标坐标
    int y=this->mapFromGlobal(QCursor().pos()).y();

    if(y + demo1->height() / 2 > this->height()) {

        //悬浮窗不动三角形动
//        demo1->move(x,height() - demo1->height() -30);              //与最下面边框留出30的距离
//        demo1->setStartPos(demo1->height() - (height() - y -30));

        //三角形不动悬浮窗动
        demo1->move(x,y - demo1->height() + 40);              //与最下面边框留出30的距离， 阴影有10 所以加40
        demo1->setStartPos(demo1->height() - 40);

        demo1->show();

    } else if(y < demo1->height() / 2){

        //悬浮窗不动三角形动
//        demo1->move(x,30);              //与最上面边框留出30的距离
//        demo1->setStartPos(y - 30);

        //三角形不动悬浮窗动
        demo1->move(x,y - 40);              //将悬浮窗顶端距离鼠标40
        demo1->setStartPos(40);

        demo1->show();

    } else {
        demo1->move(QPoint(x,y - demo1->height()/2));  //将悬浮窗以鼠标居中
        demo1->setStartPos(demo1->height() / 2);

        demo1->show();

    }
}
