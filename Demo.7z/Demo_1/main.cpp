﻿#include "demo_1.h"
#include <QApplication>
#include "test.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    Demo_1 w;
//    w.show();

    Test T;
    T.show();

    return a.exec();
}
