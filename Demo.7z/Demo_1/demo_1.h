﻿#ifndef DEMO_1_H
#define DEMO_1_H

#include <QWidget>
#include <QLabel>
#include "arrowwidget.h"

namespace Ui {
class Demo_1;
}

class Demo_1 : public ArrowWidget
{
    Q_OBJECT

public:
    explicit Demo_1(QWidget *parent = nullptr);
    ~Demo_1();

private:
    Ui::Demo_1 *ui;

private:
  int  getWidth(int width);

public slots:

private:
  ArrowWidget * form;

  //名称
      QLabel *lab_1;
      QLabel *lab_2;
      QLabel *lab_3;
      QLabel *lab_4;
      QLabel *lab_5;
      QLabel *lab_6;
      QLabel *lab_7;
      QLabel *lab_8;
      QLabel *lab_9;

  //内容
      QLabel *lab_1_1;
      QLabel *lab_2_1;
      QLabel *lab_3_1;
      QLabel *lab_4_1;
      QLabel *lab_5_1;
      QLabel *lab_6_1;
      QLabel *lab_7_1;
      QLabel *lab_8_1;
      QLabel *lab_9_1;
};

#endif // DEMO_1_H
