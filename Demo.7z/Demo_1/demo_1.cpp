﻿#include "demo_1.h"
#include "ui_demo_1.h"

#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFontMetrics>
#include <QFont>
#include <QDebug>

#pragma execution_character_set("utf-8")


#define LAYOUT_Margin 30  //布局距离边上距离


Demo_1::Demo_1(QWidget *parent) :
    ArrowWidget(parent),
    ui(new Ui::Demo_1)
{
    form = new ArrowWidget;

//    QFont font;
//    font.setPixelSize(12);
//    font.setFamily("Microsoft YaHei");
//    QFontMetrics fm(font);
//    int pixelsWide = fm.width("What's the width of this text?");
//    int pixelsHigh = fm.height();

//名称
    lab_1 = new QLabel;
    lab_2 = new QLabel;
    lab_3 = new QLabel;
    lab_4 = new QLabel;
    lab_5 = new QLabel;
    lab_6 = new QLabel;
    lab_7 = new QLabel;
    lab_8 = new QLabel;
    lab_9 = new QLabel;

//内容
    lab_1_1 = new QLabel;
    lab_2_1 = new QLabel;
    lab_3_1 = new QLabel;
    lab_4_1 = new QLabel;
    lab_5_1 = new QLabel;
    lab_6_1 = new QLabel;
    lab_7_1 = new QLabel;
    lab_8_1 = new QLabel;
    lab_9_1 = new QLabel;


    lab_1->setText("部件名称：");
    lab_2->setText("故障模式：");
    lab_3->setText("故障原因：");
    lab_4->setText("局部影响：");
    lab_5->setText("上层影响：");
    lab_6->setText("最终影响：");
    lab_7->setText("功能影响：");
    lab_8->setText("任务影响：");
    lab_9->setText("危害等级：");

    lab_1_1->setText("定大小的框内显mjjgvm示字符串");
    lab_2_1->setText("项目需要在一个固定大小的label框内显示字符串");
    lab_3_1->setText("项目11由于字符串过长，所以需要换行项目需要在一个固定大小的label框内显示字符串");
    lab_4_1->setText("项目需要在一个固定大小的label框内显示字符串，由于字");
    lab_5_1->setText("项目需要在一个固定大小的label框内显示字符串，由于字符串过长ccxv xcvxc，所以需要换行");
    lab_6_1->setText("项目需要在一个固定大小的label框内显示字符串，由于字符串过长，所以需要换行");
    lab_7_1->setText("项目需要在一个固定大小的label框内显示字符串，由于字符串过长，所以需要换行");
    lab_8_1->setText("所以需要换行");
    lab_9_1->setText("项目需要在一个固定大小的label框内显示字符串，由于字符串过长，所以需要换行项目需要在一个固定大小的label框内显示字符串，由于字符串过长，所以需要换行项目需要在一个固定大小的label框内显示字符串，由于字符串过长，所以需要换行项目需要在一个固定大小的label框内显示字符串，由于字符串过长，所以需要换行项目需要在一个固定大小的label框内显示字符串");


//布局
    QHBoxLayout *hlayout_1 =  new QHBoxLayout;
    QHBoxLayout *hlayout_2 =  new QHBoxLayout;
    QHBoxLayout *hlayout_3 =  new QHBoxLayout;
    QHBoxLayout *hlayout_4 =  new QHBoxLayout;
    QHBoxLayout *hlayout_5 =  new QHBoxLayout;
    QHBoxLayout *hlayout_6 =  new QHBoxLayout;
    QHBoxLayout *hlayout_7 =  new QHBoxLayout;
    QHBoxLayout *hlayout_8 =  new QHBoxLayout;
    QHBoxLayout *hlayout_9 =  new QHBoxLayout;



    hlayout_1->addWidget(lab_1);
    hlayout_1->addWidget(lab_1_1);

    hlayout_2->addWidget(lab_2);
    hlayout_2->addWidget(lab_2_1);

    hlayout_3->addWidget(lab_3);
    hlayout_3->addWidget(lab_3_1);

    hlayout_4->addWidget(lab_4);
    hlayout_4->addWidget(lab_4_1);

    hlayout_5->addWidget(lab_5);
    hlayout_5->addWidget(lab_5_1);

    hlayout_6->addWidget(lab_6);
    hlayout_6->addWidget(lab_6_1);

    hlayout_7->addWidget(lab_7);
    hlayout_7->addWidget(lab_7_1);

    hlayout_8->addWidget(lab_8);
    hlayout_8->addWidget(lab_8_1);

    hlayout_9->addWidget(lab_9);
    hlayout_9->addWidget(lab_9_1);

    hlayout_1->setAlignment(Qt::AlignLeft);
    hlayout_2->setAlignment(Qt::AlignLeft);
    hlayout_3->setAlignment(Qt::AlignLeft);
    hlayout_4->setAlignment(Qt::AlignLeft);
    hlayout_4->setAlignment(Qt::AlignLeft);
    hlayout_5->setAlignment(Qt::AlignLeft);
    hlayout_6->setAlignment(Qt::AlignLeft);
    hlayout_7->setAlignment(Qt::AlignLeft);
    hlayout_8->setAlignment(Qt::AlignLeft);
    hlayout_9->setAlignment(Qt::AlignLeft);






    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setMargin(LAYOUT_Margin);


    layout->addLayout(hlayout_1);
    layout->addLayout(hlayout_2);
    layout->addLayout(hlayout_3);
    layout->addLayout(hlayout_4);
    layout->addLayout(hlayout_5);
    layout->addLayout(hlayout_6);
    layout->addLayout(hlayout_7);
    layout->addLayout(hlayout_8);
    layout->addLayout(hlayout_9);


//    lab_1_1->setMaximumWidth(600); //设置最大长度
    lab_1_1->setMinimumWidth(300);

    /*自适应大小,可有可无*/
    lab_1_1->adjustSize();
    /*自动换行*/
    lab_1_1->setWordWrap(true);
//    lab_1_1->setAlignment(Qt::AlignLeft);


//    lab_2_1->setMaximumWidth(600);
    lab_2_1->setMinimumWidth(300);
    lab_2_1->adjustSize();
    lab_2_1->setWordWrap(true);


//    lab_3_1->setMaximumWidth(600);
    lab_3_1->setMinimumWidth(300);
    lab_3_1->adjustSize();
    lab_3_1->setWordWrap(true);


//    lab_4_1->setMaximumWidth(600);
    lab_4_1->setMinimumWidth(300);
    lab_4_1->adjustSize();
    lab_4_1->setWordWrap(true);


//    lab_5_1->setMaximumWidth(600);
    lab_5_1->setMinimumWidth(300);
    lab_5_1->adjustSize();
    lab_5_1->setWordWrap(true);


//    lab_6_1->setMaximumWidth(600);
    lab_6_1->setMinimumWidth(300);
    lab_6_1->adjustSize();
    lab_6_1->setWordWrap(true);


//    lab_7_1->setMaximumWidth(600);
    lab_7_1->setMinimumWidth(300);
    lab_7_1->adjustSize();
    lab_7_1->setWordWrap(true);


//    lab_8_1->setMaximumWidth(600);
    lab_8_1->setMinimumWidth(300);
    lab_8_1->adjustSize();
    lab_8_1->setWordWrap(true);


//    lab_9_1->setMaximumWidth(600);
    lab_9_1->setMinimumWidth(300);
    lab_9_1->adjustSize();
    lab_9_1->setWordWrap(true);


    layout->setSpacing(10);
    layout->setSizeConstraint(QLayout::SetFixedSize);


    ui->setupUi(this);
}

Demo_1::~Demo_1()
{

    delete ui;
}


int Demo_1::getWidth(int width)   //设置内容Label长度
{
    return width;
}


