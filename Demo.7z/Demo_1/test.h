﻿#ifndef TEST_H
#define TEST_H

#include <QWidget>
#include "demo_1.h"
#include "arrowwidget.h"
#include <QPushButton>

namespace Ui {
class Test;
}

class Test : public QWidget
{
    Q_OBJECT

public:
    explicit Test(QWidget *parent = nullptr);
    ~Test();

protected:
    virtual bool eventFilter(QObject *obj, QEvent *ev);

private:
    Ui::Test *ui;

    Demo_1 *demo1;

private:
    void Jposition(); //进行窗口位置确定


};

#endif // TEST_H
